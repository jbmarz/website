// Wait for the page to load before checking cookies
window.addEventListener('load', checkCookies);

function checkCookies() {
  if (!localStorage.getItem('cookiesAccepted')) {
    // Cookies have not been accepted, show the pop-up window
    const cookieConsent = document.getElementById('cookie-consent');
    cookieConsent.style.display = 'block';

    // Add event listener for the accept button
    const acceptButton = document.getElementById('accept-cookies');
    acceptButton.addEventListener('click', acceptCookies);
  }
}

function acceptCookies() {
  // Set a flag in local storage to remember that the user has accepted cookies
  localStorage.setItem('cookiesAccepted', 'true');

  // Hide the cookie consent pop-up window
  const cookieConsent = document.getElementById('cookie-consent');
  cookieConsent.style.display = 'none';
}