// Define variables for the game
let canvas, ctx;
let snake = [];
let food = {};
let score = 0;
let highScore = 0;
let direction = "right";
let gameLoopInterval;

// Define variables for HTML elements
const startButton = document.getElementById("startBtn");
const scoreElement = document.getElementById("score");
const highScoreElement = document.getElementById("high-score");
const gameOverPopup = document.getElementById("game-over");
const playAgainButton = document.getElementById("play-again");

// Define constants for the game
const CELL_SIZE = 10;
const GRID_WIDTH = 52;
const GRID_HEIGHT = 40;
const START_POSITION = { x: 10, y: 10 };
const FOOD_COLOR = "red";
const SNAKE_COLOR = "lightgreen";
const BORDER_COLOR = "rgb(151, 149, 149)";
const GAME_LOOP_INTERVAL_MS = 100;

// Define utility functions for the game
function getRandomCoordinate(max) {
  return Math.floor(Math.random() * max) * CELL_SIZE;
}

function drawCell(x, y, color) {
  ctx.fillStyle = color;
  ctx.fillRect(x, y, CELL_SIZE, CELL_SIZE);
  ctx.strokeStyle = BORDER_COLOR;
  ctx.strokeRect(x, y, CELL_SIZE, CELL_SIZE);
}

function drawSnake() {
  snake.forEach((segment) => {
    drawCell(segment.x, segment.y, SNAKE_COLOR);
  });
}

function advanceSnake() {
  const head = { x: snake[0].x, y: snake[0].y };

  switch (direction) {
    case "right":
      head.x += CELL_SIZE;
      break;
    case "left":
      head.x -= CELL_SIZE;
      break;
    case "up":
      head.y -= CELL_SIZE;
      break;
    case "down":
      head.y += CELL_SIZE;
      break;
    default:
      return;
  }

  snake.unshift(head);

  if (head.x === food.x && head.y === food.y) {
    score++;
    generateFood();
  } else {
    snake.pop();
  }
}

function generateFood() {
  let x = getRandomCoordinate(GRID_WIDTH);
  let y = getRandomCoordinate(GRID_HEIGHT);

  // Make sure the food doesn't spawn inside the snake
  if (snake.some((segment) => segment.x === x && segment.y === y)) {
    return generateFood();
  }

  food = { x, y };
}

function handleCollision() {
  const head = snake[0];
  const hitLeftWall = head.x < 0;
  const hitRightWall = head.x >= canvas.width;
  const hitTopWall = head.y < 0;
  const hitBottomWall = head.y >= canvas.height;

  if (hitLeftWall || hitRightWall || hitTopWall || hitBottomWall) {
    endGame();
    return;
  }

  // Check if the snake hit itself
  for (let i = 1; i < snake.length; i++) {
    if (head.x === snake[i].x && head.y === snake[i].y) {
      endGame();
      return;
    }
  }
}

function updateScore() {
  scoreElement.innerHTML = `Score: ${score}`;
  highScoreElement.innerHTML = `High Score: ${highScore}`;
}

function update() {
  advanceSnake();
  draw();
  handleCollision();
  updateScore();
}

function draw() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  drawCell(food.x, food.y, FOOD_COLOR);
}
  
function moveSnake() {
  let newHead = getNextHeadPosition();
  snake.unshift(newHead);
  snake.pop();
}

function getNextHeadPosition() {
  let head = snake[0];
  let newHead = { x: head.x, y: head.y };
  switch (direction) {
    case "up":
      newHead.y -= CELL_SIZE;
      break;
    case "down":
      newHead.y += CELL_SIZE;
      break;
    case "left":
      newHead.x -= CELL_SIZE;
      break;
    case "right":
      newHead.x += CELL_SIZE;
      break;
  }
  return newHead;
}

function checkWallCollision() {
  let head = snake[0];
  return (
    head.x < 0 ||
    head.x >= canvas.width ||
    head.y < 0 ||
    head.y >= canvas.height
  );
}

function checkSelfCollision() {
  let head = snake[0];
  return snake.slice(1).some((segment) => {
    return head.x === segment.x && head.y === segment.y;
  });
}

function checkFoodCollision() {
  let head = snake[0];
  return head.x === food.x && head.y === food.y;
}

function clearCanvas() {
  ctx.fillStyle = "white";
  ctx.fillRect(0, 0, canvas.width, canvas.height);
}

function drawFood() {
  drawCell(food.x, food.y, FOOD_COLOR);
}

function drawSnake() {
  snake.forEach((segment) => {
    drawCell(segment.x, segment.y, SNAKE_COLOR);
  });
}